--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4
-- Dumped by pg_dump version 17.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "MedicExpress";
--
-- Name: MedicExpress; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "MedicExpress" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'fr-FR';


ALTER DATABASE "MedicExpress" OWNER TO postgres;

\connect "MedicExpress"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: administrator; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.administrator (
    id integer NOT NULL,
    role text
);


ALTER TABLE public.administrator OWNER TO postgres;

--
-- Name: deliverydriver; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.deliverydriver (
    kbis integer NOT NULL,
    rate integer,
    available boolean,
    currentorder integer
);


ALTER TABLE public.deliverydriver OWNER TO postgres;

--
-- Name: doctor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.doctor (
    rpps integer NOT NULL
);


ALTER TABLE public.doctor OWNER TO postgres;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    id integer NOT NULL,
    date date,
    treatment_id integer
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.orders_id_seq OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- Name: patient; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.patient (
    id integer NOT NULL,
    sex text,
    description text
);


ALTER TABLE public.patient OWNER TO postgres;

--
-- Name: pharmacy; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pharmacy (
    id integer NOT NULL,
    address text
);


ALTER TABLE public.pharmacy OWNER TO postgres;

--
-- Name: pharmacy_has_treatments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pharmacy_has_treatments (
    id_pharma integer NOT NULL,
    id_treatment integer NOT NULL,
    stocks integer
);


ALTER TABLE public.pharmacy_has_treatments OWNER TO postgres;

--
-- Name: pharmacy_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pharmacy_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pharmacy_id_seq OWNER TO postgres;

--
-- Name: pharmacy_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pharmacy_id_seq OWNED BY public.pharmacy.id;


--
-- Name: treatment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.treatment (
    id integer NOT NULL,
    name text
);


ALTER TABLE public.treatment OWNER TO postgres;

--
-- Name: treatment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.treatment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.treatment_id_seq OWNER TO postgres;

--
-- Name: treatment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.treatment_id_seq OWNED BY public.treatment.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    email character varying(255) NOT NULL,
    password character varying(255),
    name character varying(255),
    first_name character varying(255),
    role character varying(255) NOT NULL,
    reset_password_token character varying(255),
    CONSTRAINT users_role_check CHECK (((role)::text = ANY ((ARRAY['PATIENT'::character varying, 'DOCTOR'::character varying, 'DELIVERY_MAN'::character varying, 'PHARMACIST'::character varying, 'ADMIN'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- Name: pharmacy id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pharmacy ALTER COLUMN id SET DEFAULT nextval('public.pharmacy_id_seq'::regclass);


--
-- Name: treatment id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.treatment ALTER COLUMN id SET DEFAULT nextval('public.treatment_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: administrator; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.administrator (id, role) FROM stdin;
\.
COPY public.administrator (id, role) FROM '$$PATH$$/4858.dat';

--
-- Data for Name: deliverydriver; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.deliverydriver (kbis, rate, available, currentorder) FROM stdin;
\.
COPY public.deliverydriver (kbis, rate, available, currentorder) FROM '$$PATH$$/4856.dat';

--
-- Data for Name: doctor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.doctor (rpps) FROM stdin;
\.
COPY public.doctor (rpps) FROM '$$PATH$$/4857.dat';

--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (id, date, treatment_id) FROM stdin;
\.
COPY public.orders (id, date, treatment_id) FROM '$$PATH$$/4864.dat';

--
-- Data for Name: patient; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.patient (id, sex, description) FROM stdin;
\.
COPY public.patient (id, sex, description) FROM '$$PATH$$/4855.dat';

--
-- Data for Name: pharmacy; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pharmacy (id, address) FROM stdin;
\.
COPY public.pharmacy (id, address) FROM '$$PATH$$/4860.dat';

--
-- Data for Name: pharmacy_has_treatments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pharmacy_has_treatments (id_pharma, id_treatment, stocks) FROM stdin;
\.
COPY public.pharmacy_has_treatments (id_pharma, id_treatment, stocks) FROM '$$PATH$$/4865.dat';

--
-- Data for Name: treatment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.treatment (id, name) FROM stdin;
\.
COPY public.treatment (id, name) FROM '$$PATH$$/4862.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, password, name, first_name, role, reset_password_token) FROM stdin;
\.
COPY public.users (id, email, password, name, first_name, role, reset_password_token) FROM '$$PATH$$/4854.dat';

--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.orders_id_seq', 1, false);


--
-- Name: pharmacy_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pharmacy_id_seq', 1, false);


--
-- Name: treatment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.treatment_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 27, true);


--
-- Name: administrator administrator_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.administrator
    ADD CONSTRAINT administrator_pkey PRIMARY KEY (id);


--
-- Name: deliverydriver deliverydriver_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deliverydriver
    ADD CONSTRAINT deliverydriver_pkey PRIMARY KEY (kbis);


--
-- Name: doctor doctor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctor
    ADD CONSTRAINT doctor_pkey PRIMARY KEY (rpps);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: patient patient_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient
    ADD CONSTRAINT patient_pkey PRIMARY KEY (id);


--
-- Name: pharmacy_has_treatments pharmacy_has_treatments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pharmacy_has_treatments
    ADD CONSTRAINT pharmacy_has_treatments_pkey PRIMARY KEY (id_pharma, id_treatment);


--
-- Name: pharmacy pharmacy_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pharmacy
    ADD CONSTRAINT pharmacy_pkey PRIMARY KEY (id);


--
-- Name: treatment treatment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.treatment
    ADD CONSTRAINT treatment_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: administrator administrator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.administrator
    ADD CONSTRAINT administrator_id_fkey FOREIGN KEY (id) REFERENCES public.users(id);


--
-- Name: deliverydriver deliverydriver_kbis_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deliverydriver
    ADD CONSTRAINT deliverydriver_kbis_fkey FOREIGN KEY (kbis) REFERENCES public.users(id);


--
-- Name: doctor doctor_rpps_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctor
    ADD CONSTRAINT doctor_rpps_fkey FOREIGN KEY (rpps) REFERENCES public.users(id);


--
-- Name: orders orders_treatment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_treatment_id_fkey FOREIGN KEY (treatment_id) REFERENCES public.treatment(id);


--
-- Name: patient patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.patient
    ADD CONSTRAINT patient_id_fkey FOREIGN KEY (id) REFERENCES public.users(id);


--
-- Name: pharmacy_has_treatments pharmacy_has_treatments_id_pharma_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pharmacy_has_treatments
    ADD CONSTRAINT pharmacy_has_treatments_id_pharma_fkey FOREIGN KEY (id_pharma) REFERENCES public.pharmacy(id);


--
-- Name: pharmacy_has_treatments pharmacy_has_treatments_id_treatment_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pharmacy_has_treatments
    ADD CONSTRAINT pharmacy_has_treatments_id_treatment_fkey FOREIGN KEY (id_treatment) REFERENCES public.treatment(id);


--
-- PostgreSQL database dump complete
--

